#include <iostream>
#include <ctime>
using namespace std;

class ride{
    private:
    long int ride_id;
    tm request_time;
    tm accept_time;
    tm rider_cancel_time;
    tm driver_cancel_time;
    tm complete_time;
    tm ride_start_time;

    public:
    ride();
    ride(long int ride_id,tm request_time,tm accept_time,tm rider_cancel_time,tm driver_cancel_time,tm complete_time,tm ride_start_time);
    void set_accept_time(tm accept_time);
    void set_rider_cancel_time(tm rider_cancel_time);
    void set_driver_cancel_time(tm driver_cancel_time);
    void set_complete_time(tm complete_time);
    void set_ride_start_time(tm ride_start_time);
    long int get_ride_id();
};