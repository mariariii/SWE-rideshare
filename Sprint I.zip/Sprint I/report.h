#include <iostream>
#include <ctime>
using namespace std;

class report{
    private:
    long int report_id;
    int reporter_id;
    int ride_id;
    string description;
    tm reported_at;
    bool is_reviewed;

    public:
    report();
    report(long int report_id,int reporter_id,int ride_id,string description,tm reported_at,bool is_reviewed);
    void set_is_reviewed(bool is_reviewed);
};