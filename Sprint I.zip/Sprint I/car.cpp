#include "car.h"

car::car(){
    this->licence_plate=' ';
    this->make=' ';
    this->model=' ';
    this->color=' ';
}

car::car(string licence_plate,string make,string model,string color){
    this->licence_plate=licence_plate;
    this->make=make;
    this->model=model;
    this->color=color;
}
