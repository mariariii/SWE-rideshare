#include "admin.h"

admin::admin(){
    this->admin_id=0;
    this->first_name=' ';
    this->last_name=' ';
}

admin::admin(int admin_id,string first_name,string last_name){
    this->admin_id=admin_id;
    this->first_name=first_name;
    this->last_name=last_name;
}

void admin::view_report(report report_to_view){
    report_to_view.set_is_reviewed(1);
}

void admin::ban_profile(user user_to_ban){
    user_to_ban.set_is_banned(1);
}

//still have to do penalty