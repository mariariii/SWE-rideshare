#include <iostream>
#include "report.h"
#include "user.h"
using namespace std;

class admin{
    private:
    int admin_id;
    string first_name;
    string last_name;

    public:
    admin();
    admin(int admin_id,string first_name,string last_name);
    void view_report(report report_to_view);
    void issue_penalty(user user_to_penalize);
    void ban_profile(user user_to_ban);
};