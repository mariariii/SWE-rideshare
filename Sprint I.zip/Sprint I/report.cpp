#include "report.h"

report::report(){
    this->report_id=0;
    this->reporter_id=0;
    this->ride_id=0;
    this->description=' ';
    this->reported_at={0};
    this->is_reviewed=0;
}

report::report(long int report_id,int reporter_id,int ride_id,string description,tm reported_at,bool is_reviewed){
    this->report_id=report_id;
    this->reporter_id=reporter_id;
    this->ride_id=ride_id;
    this->description=description;
    this->reported_at=reported_at;
    this->is_reviewed=is_reviewed;
}

void report::set_is_reviewed(bool is_reviewed){
    this->is_reviewed=is_reviewed;
}