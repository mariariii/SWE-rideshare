#include "payment.h"

payment::payment(){
    this->payment_id=0;
    this->rider_id=0;
    this->ride_id=0;
    this->is_accepted=0;
    this->method=' ';
    this->payment_time={0};
}

payment::payment(long int payment_id,int rider_id,int ride_id,bool is_accepted,string method,tm payment_time){
    this->payment_id=payment_id;
    this->rider_id=rider_id;
    this->ride_id=ride_id;
    this->is_accepted=is_accepted;
    this->method=method;
    this->payment_time=payment_time;
}