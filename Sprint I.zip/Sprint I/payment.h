#include <iostream>
#include <ctime>
using namespace std;

class payment{
    private:
    long int payment_id;
    int rider_id;
    int ride_id;
    bool is_accepted;
    string method;
    tm payment_time;

    public:
    payment();
    payment(long int payment_id,int rider_id,int ride_id,bool is_accepted,string method,tm payment_time);
};