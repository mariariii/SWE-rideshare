#include <iostream>
#include "ride.h"
#include "car.h"
#include "payment.h"
#include "report.h"
using namespace std;

long int ride_id_counter=1;
long int payment_id_counter=1;
long int report_id_counter=1;

class user{
    private:
    int auc_id;
    string first_name;
    string last_name;
    int phone_number;
    bool is_driver;
    bool is_banned;

    public:
    user();
    user(int auc_id,string first_name,string last_name,int phone_number,bool is_driver,bool is_banned);
    ride request_ride();
    void accept_ride(ride ride_request);
    void start_ride(ride ride_request);
    void complete_ride(ride ride_request);
    void driver_cancel_ride(ride ride_request);
    void rider_cancel_ride(ride ride_request);
    payment make_payment(ride ride_request,string method);
    report make_rider_report(ride ride_request,string description);
    report make_driver_report(ride ride_request,string description);
    void set_is_banned(bool is_banned);
};