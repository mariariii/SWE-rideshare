#include <iostream>
using namespace std;

class car{
    private:
    string licence_plate;
    string make;
    string model;
    string color;

    public:
    car();
    car(string licence_plate,string make,string model,string color);
};