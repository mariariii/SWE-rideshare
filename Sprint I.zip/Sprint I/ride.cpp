#include "ride.h"

ride::ride(){
    this->ride_id=0;
    this->request_time={0};
    this->accept_time={0};
    this->rider_cancel_time={0};
    this->driver_cancel_time={0};
    this->complete_time={0};
    this->ride_start_time={0};
}

ride::ride(long int ride_id,tm request_time,tm accept_time,tm rider_cancel_time,tm driver_cancel_time,tm complete_time,tm ride_start_time){
    this->ride_id=ride_id;
    this->request_time=request_time;
    this->accept_time=accept_time;
    this->rider_cancel_time=rider_cancel_time;
    this->driver_cancel_time=driver_cancel_time;
    this->complete_time=complete_time;
    this->ride_start_time=ride_start_time;
}

void ride::set_accept_time(tm accept_time){
    this->accept_time=accept_time;
}
void ride::set_rider_cancel_time(tm rider_cancel_time){
    this->rider_cancel_time=rider_cancel_time;
}
void ride::set_driver_cancel_time(tm driver_cancel_time){
    this->driver_cancel_time=driver_cancel_time;
}
void ride::set_complete_time(tm complete_time){
    this->complete_time=complete_time;
}
void ride::set_ride_start_time(tm ride_start_time){
    this->ride_start_time=ride_start_time;
}
long int ride::get_ride_id(){
    return this->ride_id;
}