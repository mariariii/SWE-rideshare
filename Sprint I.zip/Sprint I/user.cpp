#include "user.h"

user::user(){
    this->auc_id=0;
    this->first_name=' ';
    this->last_name=' ';
    this->phone_number=0;
    this->is_driver=0;
    this->is_banned=0;
}

user::user(int auc_id,string first_name,string last_name,int phone_number,bool is_driver,bool is_banned){
    this->auc_id=auc_id;
    this->first_name=first_name;
    this->last_name=last_name;
    this->phone_number=phone_number;
    this->is_driver=is_driver;
    this->is_banned=is_banned;
}

ride user::request_ride(){
    if (!this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm request_time=*localtime(&now);
        ride* ride_requested = new ride(ride_id_counter++,request_time,{0},{0},{0},{0},{0});
    }
    else 
        exit(0);
}

void user::accept_ride(ride ride_request){
    if (this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm accept_time=*localtime(&now);
        ride_request.set_accept_time(accept_time);
    }
    else 
        exit(0);
}

void user::start_ride(ride ride_request){
    if (this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm ride_start_time=*localtime(&now);
        ride_request.set_ride_start_time(ride_start_time);
    }
    else 
        exit(0);
}

void user::complete_ride(ride ride_request){
    if (this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm complete_time=*localtime(&now);
        ride_request.set_complete_time(complete_time);
    }
    else 
        exit(0);
}

void user::driver_cancel_ride(ride ride_request){
    if (this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm driver_cancel_time=*localtime(&now);
        ride_request.set_driver_cancel_time(driver_cancel_time);
    }
    else 
        exit(0);
}

void user::rider_cancel_ride(ride ride_request){
    if (!this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm rider_cancel_time=*localtime(&now);
        ride_request.set_rider_cancel_time(rider_cancel_time);
    }
    else 
        exit(0);
}

payment user::make_payment(ride ride_request,string method){
    if (!this->is_driver && !this->is_banned){
        if (method=="Cash" || method=="Telda" || method=="Instapay"){
            bool is_accepted;
            time_t now = time(0);
            tm payment_time=*localtime(&now);
            payment* pay = new payment(payment_id_counter++,this->auc_id,ride_request.get_ride_id(),is_accepted,method,payment_time);
            return *pay;
        }
        else{
            cout << "Invalid payment method chosen, try again." << endl;
            return;
        }
    }
    else 
        return;
}

report user::make_driver_report(ride ride_request,string description){
    if (this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm reported_at=*localtime(&now);
        report* new_report = new report(report_id_counter++,this->auc_id,ride_request.get_ride_id(),description,reported_at,0);
        return *new_report;
    }
    else 
        exit(0);
}

report user::make_rider_report(ride ride_request,string description){
    if (!this->is_driver && !this->is_banned){
        time_t now = time(0);
        tm reported_at=*localtime(&now);
        report* new_report = new report(report_id_counter++,this->auc_id,ride_request.get_ride_id(),description,reported_at,0);
        return *new_report;
    }
    else 
        exit(0);
}

void user::set_is_banned(bool is_banned){
    this->is_banned=is_banned;
}