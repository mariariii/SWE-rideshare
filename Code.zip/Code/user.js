const Ride = require('./ride');
const Payment = require('./payment');
const Report = require('./report');
const Car = require('./car');
const Request = require('./request');

// Global counters for IDs
let rideIdCounter = 1;
let paymentIdCounter = 1;
let reportIdCounter = 1;

class user {
    constructor(
        aucId = 0,
        firstName = '',
        lastName = '',
        phoneNumber = 0,
        isDriver = false,
        isBanned = false,
        cars = [], // Array to hold Car objects (only for drivers)
        friends = [], // Array to hold friends 
        blockedBy = [], // Array to hold users who blocked current user
        preferences = [] //Array to hold user preferences (strings)
    ) {
        this.aucId = aucId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.isDriver = isDriver;
        this.isBanned = isBanned;
        this.cars = isDriver ? cars : []; // Only drivers can have cars
        this.friends = friends;
        this.blockedBy = blockedBy;
        this.preferences=preferences;
    }

    // Getter and Setter for aucId
    get aucId() {
        return this._aucId;
    }
    set aucId(value) {
        this._aucId = value;
    }

    // Getter and Setter for firstName
    get firstName() {
        return this._firstName;
    }
    set firstName(value) {
        this._firstName = value;
    }

    // Getter and Setter for lastName
    get lastName() {
        return this._lastName;
    }
    set lastName(value) {
        this._lastName = value;
    }

    // Getter and Setter for phoneNumber
    get phoneNumber() {
        return this._phoneNumber;
    }
    set phoneNumber(value) {
        this._phoneNumber = value;
    }

    // Getter and Setter for isDriver
    get isDriver() {
        return this._isDriver;
    }
    set isDriver(value) {
        this._isDriver = value;
        // Optionally, reset cars if user is no longer a driver
        if (!value) {
            this._cars = [];
        }
    }

    // Getter and Setter for isBanned
    get isBanned() {
        return this._isBanned;
    }
    set isBanned(value) {
        this._isBanned = value;
    }

    // Getter and Setter for cars
    get cars() {
        return this._cars;
    }
    set cars(value) {
        // Only drivers can have cars
        if (this._isDriver) {
            this._cars = value;
        } else {
            this._cars = [];
        }
    }

    // Getter and Setter for friends
    get friends() {
        return this._friends;
    }
    set friends(value) {
        this._friends = value;
    }

    // Getter and Setter for blockedBy
    get blockedBy() {
        return this._blockedBy;
    }
    set blockedBy(value) {
        this._blockedBy = value;
    }

    // Getter and Setter for preferences
    get preferences() {
        return this._preferences;
    }
    set preferences(value) {
        this._preferences = value;
    }

    //Method to add preference
    addPreference(preference) {
        this.preferences.push(preference);
    }

    // Method to request a ride
    requestRide() {
        if (!this.isDriver && !this.isBanned) {
            const now = new Date();
            return new Ride(rideIdCounter++, now, null, null, null, null, null);
        } else {
            throw new Error('User cannot request a ride.');
        }
    }

    // Method to accept a ride
    acceptRide(rideRequest) {
        if (this.isDriver && !this.isBanned) {
            const now = new Date();
            rideRequest.acceptTime = now;
        } else {
            throw new Error('User cannot accept a ride.');
        }
    }

    // Method to start a ride
    startRide(rideRequest) {
        if (this.isDriver && !this.isBanned) {
            const now = new Date();
            rideRequest.rideStartTime = now;
        } else {
            throw new Error('User cannot start a ride.');
        }
    }

    // Method to complete a ride
    completeRide(rideRequest) {
        if (this.isDriver && !this.isBanned) {
            const now = new Date();
            rideRequest.completeTime = now;
        } else {
            throw new Error('User cannot complete a ride.');
        }
    }

    // Method for driver to cancel a ride
    driverCancelRide(rideRequest) {
        if (this.isDriver && !this.isBanned) {
            const now = new Date();
            rideRequest.riderCancelTime = now;
        } else {
            throw new Error('User cannot cancel a ride as a driver.');
        }
    }

    // Method for rider to cancel a ride
    riderCancelRide(rideRequest) {
        if (!this.isDriver && !this.isBanned) {
            const now = new Date();
            rideRequest.riderCancelTime = now;
        } else {
            throw new Error('User cannot cancel a ride as a rider.');
        }
    }

    // Method to make a payment
    makePayment(rideRequest, method) {
        if (!this.isDriver && !this.isBanned) {
            if (['Cash', 'Telda', 'Instapay'].includes(method)) {
                const now = new Date();
                return new Payment(paymentIdCounter++, this.aucId, rideRequest.getRideId(), true, method, now);
            } else {
                throw new Error('Invalid payment method chosen.');
            }
        } else {
            throw new Error('User cannot make a payment.');
        }
    }

    // Method for driver to make a report
    makeDriverReport(rideRequest, description) {
        if (this.isDriver && !this.isBanned) {
            const now = new Date();
            return new Report(reportIdCounter++, this.aucId, rideRequest.getRideId(), description, now, false);
        } else {
            throw new Error('User cannot make a driver report.');
        }
    }

    // Method for rider to make a report
    makeRiderReport(rideRequest, description) {
        if (!this.isDriver && !this.isBanned) {
            const now = new Date();
            return new Report(reportIdCounter++, this.aucId, rideRequest.getRideId(), description, now, false);
        } else {
            throw new Error('User cannot make a rider report.');
        }
    }

    // Method to add a car (only for drivers)
    addCar(car) {
        if (this.isDriver) {
            if (car instanceof Car) {
                this.cars.push(car);
            } else {
                throw new Error('Invalid car object.');
            }
        } else {
            throw new Error('Only drivers can own cars.');
        }
    }

    //Method to send friend request
    sendRequest(receiver) {
        if (this.isBanned) {
            throw new Error('User cannot send friend request.');
        }
        if (receiver.blockedBy.includes(this.aucId)) { //check if sender is blocked by receiver
            throw new Error('You are blocked by this user and cannot send a friend request.');
        }
        const now = new Date();
        return new Request(this.aucId, receiver.aucId, now, "Pending");
    }

    //Method to accept friend request
    acceptRequest(request) {
        if (!this.isBanned) {
            request.status = "Accepted";
        }
        else {
            throw new Error('User cannot accept friend request.');
        }
    }

    //Method to decline friend request
    declineRequest(request) {
        if (!this.isBanned) {
            request.status = "Declined";
        }
        else {
            throw new Error('User cannot decline friend request.');
        }
    }

    //Method to block user
    blockUser(user) {
        if (!this.isBanned) {
            user.blockedBy.push(this.aucId);
        }
    } 

}


module.exports = user;
