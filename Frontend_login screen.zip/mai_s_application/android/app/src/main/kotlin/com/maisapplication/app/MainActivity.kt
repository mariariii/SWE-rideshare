package com.maisapplication.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
